package com.example.developerhub;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import androidx.appcompat.app.AppCompatActivity;

public class AccountTypeActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_account_type);

        // Initialize buttons
        Button btnAsDeveloper = findViewById(R.id.btnAsDeveloper);
        Button btnAsHiringManager = findViewById(R.id.btnAsHiringManager);

        // Set onClick listeners for buttons
        btnAsDeveloper.setOnClickListener(view -> navigateToChooseOption("Developer"));
        btnAsHiringManager.setOnClickListener(view -> navigateToChooseOption("HiringManager"));
    }

    private void navigateToChooseOption(String accountType) {
        Intent intent = new Intent(AccountTypeActivity.this, ChooseOptionActivity.class);
        intent.putExtra("ACCOUNT_TYPE", accountType); // Pass account type to ChooseOptionActivity
        startActivity(intent);
    }
}