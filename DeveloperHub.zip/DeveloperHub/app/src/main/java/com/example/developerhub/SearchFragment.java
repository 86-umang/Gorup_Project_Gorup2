package com.example.developerhub;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.List;

public class SearchFragment extends Fragment {

    private RecyclerView developersRecyclerView;
    private DeveloperAdapter developerAdapter;
    private List<Developer> developerList;
    private DatabaseReference developersRef;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_search, container, false);

        developersRecyclerView = view.findViewById(R.id.developersRecyclerView);
        developersRecyclerView.setLayoutManager(new LinearLayoutManager(getContext()));
        developerList = new ArrayList<>();
        // Update the constructor call here
        developerAdapter = new DeveloperAdapter(getContext(), developerList, new DeveloperAdapter.OnDeveloperClickListener() {
            @Override
            public void onDeveloperClick(Developer developer) {
                // Handle the click event. For example, showing a Toast message or starting a new activity.
                Toast.makeText(getContext(), "Clicked on " + developer.getFullName(), Toast.LENGTH_SHORT).show();
                // Example for starting a detailed view activity
                Intent intent = new Intent(getContext(), DeveloperDetailActivity.class);
                intent.putExtra("firstName", developer.getFirstName());
                intent.putExtra("lastName", developer.getLastName());
                intent.putExtra("education", developer.getEducation());
                intent.putExtra("graduationYear", developer.getGraduationYear());
                intent.putExtra("companyName", developer.getCompanyName());
                intent.putExtra("experience", developer.getExperience());
                intent.putExtra("contactNo", developer.getContactNo());
                intent.putExtra("profileImageUrl", developer.getProfileImageUrl());
                intent.putExtra("mobileNumber", developer.getMobileNumber());
                intent.putExtra("technologyKeys", developer.getTechnologyKeys());
                startActivity(intent);
            }
        });
        developersRecyclerView.setAdapter(developerAdapter);

        // Reference to your Firebase node where developers are stored
        developersRef = FirebaseDatabase.getInstance().getReference("developerDetails");

        fetchDevelopers();
        return view;
    }

    private void fetchDevelopers() {
        developersRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                developerList.clear(); // Clear the list to avoid duplicate entries
                for (DataSnapshot developerSnapshot : dataSnapshot.getChildren()) {
                    Developer developer = developerSnapshot.getValue(Developer.class);
                    developerList.add(developer);
                }
                developerAdapter.notifyDataSetChanged(); // Notify the adapter that data has changed
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
                Toast.makeText(getContext(), "Failed to load developers.", Toast.LENGTH_SHORT).show();
            }
        });
    }
}
