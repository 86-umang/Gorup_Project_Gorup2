package com.example.developerhub;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.os.Handler;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class RegisterActivity extends AppCompatActivity {

    private EditText nameEditText, emailEditText, usernameEditText, passwordEditText;
    private Button signUpButton;
    private TextView loginRedirectText;

    private FirebaseAuth mAuth;
    private DatabaseReference mDatabase;

    private LinearLayout layoutReg;
    String emailPattern = "[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\\.[a-zA-Z]{2,}";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        mAuth = FirebaseAuth.getInstance();
        mDatabase = FirebaseDatabase.getInstance().getReference();

        nameEditText = findViewById(R.id.signup_name);
        emailEditText = findViewById(R.id.signup_email);
        usernameEditText = findViewById(R.id.signup_username);
        passwordEditText = findViewById(R.id.signup_password);
        signUpButton = findViewById(R.id.signup_button);
        loginRedirectText = findViewById(R.id.loginRedirectText);

        layoutReg = findViewById(R.id.layourReg);

        signUpButton.setOnClickListener(v -> registerUser());
        loginRedirectText.setOnClickListener(view -> {
            startActivity(new Intent(RegisterActivity.this, LoginActivity.class));
            finish();
        });
    }

    private void registerUser() {
        String name = nameEditText.getText().toString().trim();
        String email = emailEditText.getText().toString().trim();
        String username = usernameEditText.getText().toString().trim();
        String password = passwordEditText.getText().toString().trim();
        String accountType = getIntent().getStringExtra("ACCOUNT_TYPE");

        if (name.isEmpty() || email.isEmpty() || username.isEmpty() || password.isEmpty()) {
            UtilitySnack.showErrorSnackbar(this, layoutReg, "All fields are required.");

        } else if (!email.matches(emailPattern)) {
            UtilitySnack.showErrorSnackbar(this, layoutReg, "Invalid mail Id.");

        } else if (password.length() < 8) {
            UtilitySnack.showErrorSnackbar(this, layoutReg, "Password must contain 8 or more chars.");

        } else {
            mAuth.createUserWithEmailAndPassword(email, password)
                    .addOnCompleteListener(this, task -> {
                        if (task.isSuccessful()) {
                            String userId = mAuth.getCurrentUser().getUid();
                            User user = new User(name, email, username, accountType);
                            mDatabase.child("users").child(userId).setValue(user)
                                    .addOnCompleteListener(task1 -> {
                                        if (task1.isSuccessful()) {
                                            UtilitySnack.showErrorSnackbar(this, layoutReg, "Account Created.");

                                            new Handler().postDelayed(new Runnable() {
                                                @Override
                                                public void run() {
                                                    navigateToForm(accountType);
                                                }
                                            }, 2000);

                                        } else {
                                            UtilitySnack.showErrorSnackbar(this, layoutReg, "Failed to save user details.");

                                        }
                                    });
                        } else {
                            UtilitySnack.showErrorSnackbar(this, layoutReg, "Authentication failed.");


                        }
                    });
        }

    }

    private void navigateToForm(String accountType) {
        if ("Developer".equals(accountType)) {
            startActivity(new Intent(RegisterActivity.this, DeveloperFormActivity.class));
        } else if ("HiringManager".equals(accountType)) {
            startActivity(new Intent(RegisterActivity.this, HiringManagerFormActivity.class));
        }
    }

    static class User {
        public String name;
        public String email;
        public String username;
        public String accountType;

        public User() {
        }

        public User(String name, String email, String username, String accountType) {
            this.name = name;
            this.email = email;
            this.username = username;
            this.accountType = accountType;
        }
    }
}
