package com.example.developerhub;

import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.bumptech.glide.Glide;

import java.util.HashMap;
import java.util.Map;

public class DeveloperDetailActivity extends AppCompatActivity {

    private ImageView profileImageView;
    private TextView nameTextView, educationTextView, graduationYearTextView, companyNameTextView, experienceTextView, firstNameTextView, lastNameTextView, technologyTextView, mobileNumberTextView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.developer_detail_screen);

        profileImageView = findViewById(R.id.profileImg);
        nameTextView = findViewById(R.id.titleName);
        educationTextView = findViewById(R.id.educationName);
        graduationYearTextView = findViewById(R.id.graduationYear);
        companyNameTextView = findViewById(R.id.companyName);
        experienceTextView = findViewById(R.id.experienceYears);
        firstNameTextView = findViewById(R.id.firstName);
        lastNameTextView = findViewById(R.id.lastName);
        mobileNumberTextView = findViewById(R.id.mobileNumber);
        technologyTextView = findViewById(R.id.technology);

        // Get the details passed from SearchFragment or any other activity
        String firstName = getIntent().getStringExtra("firstName");
        String lastName = getIntent().getStringExtra("lastName");
        String fullName = firstName + " " + lastName;
        String education = getIntent().getStringExtra("education");
        String graduationYear = getIntent().getStringExtra("graduationYear");
        String companyName = getIntent().getStringExtra("companyName");
        String experience = getIntent().getStringExtra("experience");
        String profileImageUrl = getIntent().getStringExtra("profileImageUrl");
        String mobileNumber = getIntent().getStringExtra("mobileNumber");
        String technologyKeys = getIntent().getStringExtra("technologyKeys");

        String technologyData = getIntent().getStringExtra("technology");
        Map<String, Boolean> technologyMap = deserializeTechnologyData(technologyData); // You need to implement this method

        String trueTechnologies = extractTrueTechnologies(technologyMap);
        technologyTextView.setText(technologyKeys);

        // Set the retrieved details to corresponding views
        nameTextView.setText(fullName);
        educationTextView.setText(education);
        graduationYearTextView.setText(graduationYear);
        companyNameTextView.setText(companyName);
        experienceTextView.setText(experience);
        firstNameTextView.setText(firstName);
        lastNameTextView.setText(lastName);
        mobileNumberTextView.setText(mobileNumber);

        // Load profile image using Glide library
        Glide.with(this)
                .load(profileImageUrl)
                .placeholder(R.drawable.baseline_person_pin_24)
                .into(profileImageView);
    }

    private Map<String, Boolean> deserializeTechnologyData(String serializedData) {
        // Implement deserialization logic here based on how you serialize the map.
        // This is just a placeholder. Actual implementation will depend on the serialization method used.
        return new HashMap<>();
    }

    private String extractTrueTechnologies(Map<String, Boolean> technologyMap) {
        StringBuilder technologies = new StringBuilder();
        for (Map.Entry<String, Boolean> entry : technologyMap.entrySet()) {
            if (entry.getValue()) { // If the value is true
                if (technologies.length() > 0) technologies.append(", ");
                technologies.append(entry.getKey());
            }
        }
        return technologies.toString();
    }
}
