package com.example.developerhub;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;

import java.util.List;

public class DeveloperAdapter extends RecyclerView.Adapter<DeveloperAdapter.DeveloperViewHolder> {

    private Context context;
    private List<Developer> developers;
    private OnDeveloperClickListener listener;

    public interface OnDeveloperClickListener {
        void onDeveloperClick(Developer developer);
    }

    public DeveloperAdapter(Context context, List<Developer> developers, OnDeveloperClickListener listener) {
        this.context = context;
        this.developers = developers;
        this.listener = listener;
    }

    @NonNull
    @Override
    public DeveloperViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.developer_item, parent, false);
        return new DeveloperViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull DeveloperViewHolder holder, int position) {
        Developer developer = developers.get(position);
        holder.nameTextView.setText(developer.getFullName());
        holder.experienceTextView.setText(String.format("Experience: %s years", developer.getExperience()));
        Glide.with(context).load(developer.getProfileImageUrl()).placeholder(R.drawable.baseline_person_pin_24).into(holder.imageView);

        holder.itemView.setOnClickListener(v -> listener.onDeveloperClick(developers.get(position)));
    }

    @Override
    public int getItemCount() {
        return developers.size();
    }

    static class DeveloperViewHolder extends RecyclerView.ViewHolder {
        ImageView imageView;
        TextView nameTextView, experienceTextView;

        DeveloperViewHolder(View itemView) {
            super(itemView);
            imageView = itemView.findViewById(R.id.developerImageView);
            nameTextView = itemView.findViewById(R.id.developerNameTextView);
            experienceTextView = itemView.findViewById(R.id.developerExperienceTextView);
        }
    }
}
