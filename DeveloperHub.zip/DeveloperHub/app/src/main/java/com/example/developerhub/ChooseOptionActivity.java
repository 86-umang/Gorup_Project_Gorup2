package com.example.developerhub;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import androidx.appcompat.app.AppCompatActivity;

public class ChooseOptionActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_choose_option);

        String accountType = getIntent().getStringExtra("ACCOUNT_TYPE");

        Button btnSignUp = findViewById(R.id.btnSignUp);
        Button btnSignIn = findViewById(R.id.btnSignIn);

        btnSignUp.setOnClickListener(view -> navigateToSignUpOrLogin(accountType, true));
        btnSignIn.setOnClickListener(view -> navigateToSignUpOrLogin(accountType, false));
    }

    private void navigateToSignUpOrLogin(String accountType, boolean isSignUp) {
        Intent intent;
        if (isSignUp) {
            intent = new Intent(ChooseOptionActivity.this, RegisterActivity.class);
        } else {
            intent = new Intent(ChooseOptionActivity.this, LoginActivity.class);
        }
        intent.putExtra("ACCOUNT_TYPE", accountType);
        startActivity(intent);
    }
}
