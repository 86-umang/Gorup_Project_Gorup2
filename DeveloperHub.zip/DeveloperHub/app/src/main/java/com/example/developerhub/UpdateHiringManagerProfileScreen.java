package com.example.developerhub;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.bumptech.glide.Glide;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.material.snackbar.Snackbar;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;

import javax.annotation.Nullable;

public class UpdateHiringManagerProfileScreen extends AppCompatActivity {

    private EditText usernameEditText, companyNameEditText, locationEditText, contactNoEditText;
    private Button updateButton;
    private ImageView profileImageView;

    private DatabaseReference userRef;
    private StorageReference storageRef;
    private Uri imageUri;

    private static final int PICK_IMAGE_REQUEST = 1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_update_hiring_manager_profile_screen);

        // Initialize views
        usernameEditText = findViewById(R.id.usernameEditText);
        companyNameEditText = findViewById(R.id.companyNameEditText);
        locationEditText = findViewById(R.id.locationEditText);
        contactNoEditText = findViewById(R.id.contactNoEditText);
        updateButton = findViewById(R.id.updateButton);
        profileImageView = findViewById(R.id.profileImg);

        // Initialize Firebase
        FirebaseUser currentUser = FirebaseAuth.getInstance().getCurrentUser();
        if (currentUser != null) {
            userRef = FirebaseDatabase.getInstance().getReference().child("hiringManagerDetails").child(currentUser.getUid());
            storageRef = FirebaseStorage.getInstance().getReference().child("profileImageUrl").child(currentUser.getUid());
        }

        // Fetching user's information
        fetchUserInfo();

        // Set update Button's Click Listener
        updateButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                updateProfile();
            }
        });

        // Set profile Image's Click Listener
        profileImageView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openFileChooser();
            }
        });
    }

    private void fetchUserInfo() {
        if (userRef != null) {
            userRef.addListenerForSingleValueEvent(new ValueEventListener() {
                @Override
                public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                    // Retrieve user's information from the database
                    String username = dataSnapshot.child("username").getValue(String.class);
                    String companyName = dataSnapshot.child("companyName").getValue(String.class);
                    String location = dataSnapshot.child("location").getValue(String.class);
                    String contactNo = dataSnapshot.child("contactNo").getValue(String.class);
                    String profileImageUrl = dataSnapshot.child("profileImageUrl").getValue(String.class);


                    // Set the information in the fields
                    usernameEditText.setText(username);
                    companyNameEditText.setText(companyName);
                    locationEditText.setText(location);
                    contactNoEditText.setText(contactNo);

                    // Load profile image using Glide
                    if (profileImageUrl != null && !profileImageUrl.isEmpty()) {
                        Glide.with(UpdateHiringManagerProfileScreen.this)
                                .load(profileImageUrl)
                                .placeholder(R.drawable.profilebkg) // Placeholder image while loading
                                .into(profileImageView);
                    }
                }

                @Override
                public void onCancelled(@NonNull DatabaseError databaseError) {
                }
            });
        }
    }

    private void openFileChooser() {
        Intent intent = new Intent();
        intent.setType("image/*");
        intent.setAction(Intent.ACTION_GET_CONTENT);
        startActivityForResult(intent, PICK_IMAGE_REQUEST);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == PICK_IMAGE_REQUEST && resultCode == RESULT_OK && data != null && data.getData() != null) {
            imageUri = data.getData();
            profileImageView.setImageURI(imageUri);
        }
    }

    private void updateProfile() {
        final String username = usernameEditText.getText().toString().trim();
        final String companyName = companyNameEditText.getText().toString().trim();
        final String location = locationEditText.getText().toString().trim();
        final String contactNo = contactNoEditText.getText().toString().trim();

        if (username.isEmpty() || companyName.isEmpty() || location.isEmpty() || contactNo.isEmpty()) {
            Snackbar.make(findViewById(android.R.id.content), "All fields are required", Snackbar.LENGTH_SHORT).show();
            return;
        }

        // Update profile information in Firebase Database
        if (userRef != null) {
            userRef.child("username").setValue(username);
            userRef.child("companyName").setValue(companyName);
            userRef.child("location").setValue(location);
            userRef.child("contactNo").setValue(contactNo);

            if (imageUri != null) {
                // Upload profile image to Firebase Storage
                storageRef.putFile(imageUri)
                        .addOnSuccessListener(new OnSuccessListener<UploadTask.TaskSnapshot>() {
                            @Override
                            public void onSuccess(UploadTask.TaskSnapshot taskSnapshot) {
                                // Get the download URL of the uploaded image
                                storageRef.getDownloadUrl().addOnSuccessListener(new OnSuccessListener<Uri>() {
                                    @Override
                                    public void onSuccess(Uri uri) {
                                        // Update profile image URL in Firebase Database
                                        userRef.child("profileImageUrl").setValue(uri.toString());
                                    }
                                });
                            }
                        })
                        .addOnFailureListener(new OnFailureListener() {
                            @Override
                            public void onFailure(@NonNull Exception e) {
                                Snackbar.make(findViewById(android.R.id.content), "Failed to upload image", Snackbar.LENGTH_LONG).show();
                            }
                        });
            }

            // Showing a success message to the user
            Snackbar.make(findViewById(android.R.id.content), "Profile updated successfully", Snackbar.LENGTH_LONG).show();

            // Set the result to indicate successful profile update
            setResult(Activity.RESULT_OK);

            //  Redirect to the HiringManager Profile Screen
             finish();
        }
    }
}