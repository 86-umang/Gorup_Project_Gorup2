package com.example.developerhub;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.List;

public class FindDeveloperActivity extends AppCompatActivity implements DeveloperAdapter.OnDeveloperClickListener {

    private RecyclerView developersRecyclerView;
    private DeveloperAdapter developerAdapter;
    private List<Developer> developerList;
    private DatabaseReference developersRef;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_find_developer);

        developersRecyclerView = findViewById(R.id.developersRecyclerView);
        developersRecyclerView.setLayoutManager(new LinearLayoutManager(this));
        developerList = new ArrayList<>();
        // Pass this as the click listener
        developerAdapter = new DeveloperAdapter(this, developerList, this);
        developersRecyclerView.setAdapter(developerAdapter);

        developersRef = FirebaseDatabase.getInstance().getReference("developerDetails");
        fetchDevelopers();
    }

    private void fetchDevelopers() {
        developersRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                developerList.clear();
                for (DataSnapshot developerSnapshot : dataSnapshot.getChildren()) {
                    Developer developer = developerSnapshot.getValue(Developer.class);
                    developerList.add(developer);
                }
                developerAdapter.notifyDataSetChanged();
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
                Toast.makeText(FindDeveloperActivity.this, "Failed to load developers.", Toast.LENGTH_SHORT).show();
            }
        });
    }

    @Override
    public void onDeveloperClick(Developer developer) {
        Intent intent = new Intent(FindDeveloperActivity.this, DeveloperDetailActivity.class);
        // Consider serializing the Developer object or passing individual fields as extras
        intent.putExtra("firstName", developer.getFirstName());
        intent.putExtra("lastName", developer.getLastName());
        intent.putExtra("experience", developer.getExperience());
        intent.putExtra("profileImageUrl", developer.getProfileImageUrl());
        startActivity(intent);
    }
}
