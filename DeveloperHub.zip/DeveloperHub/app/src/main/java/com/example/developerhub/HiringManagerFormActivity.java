package com.example.developerhub;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.provider.MediaStore;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;

import java.util.HashMap;
import java.util.Map;

public class HiringManagerFormActivity extends AppCompatActivity {

    private EditText usernameEditText, companyNameEditText, contactNoEditText, locationEditText;
    private Button submitButton;
    private ImageView profileImageView;
    private Uri imageUri;

    private FirebaseAuth mAuth;
    private DatabaseReference mDatabase;
    private StorageReference mStorageRef;

    LinearLayout layoutHrF;

    // ActivityResultLauncher for handling image picking result
    private ActivityResultLauncher<Intent> imagePickerActivityResultLauncher = registerForActivityResult(
            new ActivityResultContracts.StartActivityForResult(),
            result -> {
                if (result.getResultCode() == RESULT_OK && result.getData() != null) {
                    imageUri = result.getData().getData();
                    profileImageView.setImageURI(imageUri); // Show the selected image on the ImageView
                }
            });

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.hiring_manager_form);

        mAuth = FirebaseAuth.getInstance();
        mDatabase = FirebaseDatabase.getInstance().getReference();
        mStorageRef = FirebaseStorage.getInstance().getReference();
        layoutHrF=findViewById(R.id.layoutHrF);

        // Initialize your views here
        usernameEditText = findViewById(R.id.et_username);
        companyNameEditText = findViewById(R.id.et_company_name);
        contactNoEditText = findViewById(R.id.et_contact_no);
        locationEditText = findViewById(R.id.et_location);
        profileImageView = findViewById(R.id.iv_profile_image);
        submitButton = findViewById(R.id.btn_submit);

        submitButton.setOnClickListener(v -> submitHiringManagerForm());
        profileImageView.setOnClickListener(v -> pickImage());
    }

    private void pickImage() {
        Intent intent = new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
        intent.setType("image/*");
        imagePickerActivityResultLauncher.launch(intent);
    }

    private void submitHiringManagerForm() {
        String username = usernameEditText.getText().toString().trim();
        String companyName = companyNameEditText.getText().toString().trim();
        String contactNo = contactNoEditText.getText().toString().trim();
        String location = locationEditText.getText().toString().trim();

        if (!username.isEmpty() && !companyName.isEmpty() && !contactNo.isEmpty() && !location.isEmpty() && imageUri != null) {
            uploadImageToFirebase(imageUri, username, companyName, contactNo, location);
        } else {
            UtilitySnack.showErrorSnackbar(this,layoutHrF,"Please fill in all required fields and select an image.");

        }
    }

    private void uploadImageToFirebase(Uri imageUri, String username, String companyName, String contactNo, String location) {
        StorageReference fileRef = mStorageRef.child("profileImages/hiringManagers/" + mAuth.getCurrentUser().getUid() + ".jpg");
        fileRef.putFile(imageUri).addOnSuccessListener(taskSnapshot -> fileRef.getDownloadUrl().addOnSuccessListener(uri -> {
            Map<String, Object> hiringManagerDetails = new HashMap<>();
            hiringManagerDetails.put("username", username);
            hiringManagerDetails.put("companyName", companyName);
            hiringManagerDetails.put("contactNo", contactNo);
            hiringManagerDetails.put("location", location);
            hiringManagerDetails.put("profileImageUrl", uri.toString());

            mDatabase.child("hiringManagerDetails").child(mAuth.getCurrentUser().getUid()).setValue(hiringManagerDetails)
                    .addOnCompleteListener(task -> {
                        if (task.isSuccessful()) {
                            UtilitySnack.showErrorSnackbar(this,layoutHrF,"Details saved successfully");

                            new Handler().postDelayed(new Runnable() {
                                @Override
                                public void run() {
                                    // Start HomeActivity after a delay
                                    Intent intent = new Intent(getApplicationContext(), BottomNavigationActivity.class);
                                    startActivity(intent);
                                    finish();
                                }
                            }, 2000);
                            // Navigate to another activity or handle UI here
                        } else {
                            UtilitySnack.showErrorSnackbar(this,layoutHrF,"Failed to save details.");

                        }
                    });
        })).addOnFailureListener(e ->UtilitySnack.showErrorSnackbar(this,layoutHrF,"Failed to upload image."));

    }
}