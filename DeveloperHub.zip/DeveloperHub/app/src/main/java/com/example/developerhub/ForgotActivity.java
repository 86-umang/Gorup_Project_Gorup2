package com.example.developerhub;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.Toast;

import com.google.firebase.auth.FirebaseAuth;

public class ForgotActivity extends AppCompatActivity {

    EditText fEmail;
    Button forgotPwBtn;
    LinearLayout layoutForgot;
    private FirebaseAuth auth;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_forgot);

        fEmail=findViewById(R.id.forgotEmail);
        forgotPwBtn=findViewById(R.id.forgotPwBtn);
        layoutForgot=findViewById(R.id.layoutForgot);
        auth=FirebaseAuth.getInstance();
        forgotPwBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String mail=fEmail.getText().toString();
                if(TextUtils.isEmpty(mail))
                {
                    UtilitySnack.showErrorSnackbar(ForgotActivity.this,layoutForgot,"Please enter valid ID.");

                }
                else {
                    auth.sendPasswordResetEmail(mail)
                            .addOnCompleteListener(task->{
                                if(task.isSuccessful())
                                {
                                    Toast.makeText(ForgotActivity.this, "Reset Link Sent",
                                            Toast.LENGTH_SHORT).show();
                                    Intent i= new Intent(ForgotActivity.this, LoginActivity.class);
                                    startActivity(i);
                                }
                                else
                                {

                                    UtilitySnack.showErrorSnackbar(ForgotActivity.this,layoutForgot,"Please enter registered valid ID.");

                                }
                            });
                }
            }
        });


    }
}