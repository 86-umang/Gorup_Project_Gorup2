package com.example.developerhub;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.bumptech.glide.Glide;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class HiringManagerFragment extends Fragment {
    private static final int UPDATE_PROFILE_REQUEST = 1;
    private ImageView profileImageView;
    private TextView titleName, profileUserName, profileCompanyName, profileLocation, profileContactNo;

    private Button editProfile, signout;

    private final ActivityResultLauncher<Intent> updateProfileLauncher = registerForActivityResult(
            new ActivityResultContracts.StartActivityForResult(),
            result -> {
                if (result.getResultCode() == Activity.RESULT_OK) {
                    // Refresh the fragment to display updated values

                    fetchLoggedInHiringManagerInfo();
                }
            });

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.admin_profile_activity, container, false);

        // Initialize views
        profileImageView = view.findViewById(R.id.profileImg);
        titleName = view.findViewById(R.id.titleName);
        profileUserName = view.findViewById(R.id.profileUserName);
        profileCompanyName = view.findViewById(R.id.profileCompanyName);
        profileLocation = view.findViewById(R.id.profileLocation);
        profileContactNo = view.findViewById(R.id.profileContactNo);
        editProfile = view.findViewById(R.id.editButton);
        signout = view.findViewById(R.id.signoutttbtn);

        fetchLoggedInHiringManagerInfo();

        editProfile.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getActivity(), UpdateHiringManagerProfileScreen.class);
                updateProfileLauncher.launch(intent);
            }
        });

        signout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                signOutUser();
            }
        });

        return view;
    }

    private void signOutUser() {
        FirebaseAuth.getInstance().signOut();
        Intent intent = new Intent(getActivity(), MainActivity.class);
        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
        startActivity(intent);
    }

    private void fetchLoggedInHiringManagerInfo() {
        FirebaseUser currentUser = FirebaseAuth.getInstance().getCurrentUser();
        if (currentUser != null) {
            FirebaseDatabase.getInstance().getReference().child("hiringManagerDetails").child(currentUser.getUid())
                    .addListenerForSingleValueEvent(new ValueEventListener() {
                        @Override
                        public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                            // Extract data from dataSnapshot
                            String username = dataSnapshot.child("username").getValue(String.class);
                            String companyName = dataSnapshot.child("companyName").getValue(String.class);
                            String location = dataSnapshot.child("location").getValue(String.class);
                            String contactNo = dataSnapshot.child("contactNo").getValue(String.class);
                            String profileImageUrl = dataSnapshot.child("profileImageUrl").getValue(String.class);

                            // Update UI
                            titleName.setText(username); // Assuming you want to display the username as title
                            profileUserName.setText(username);
                            profileCompanyName.setText(companyName);
                            profileLocation.setText(location);
                            profileContactNo.setText(contactNo);

                            Glide.with(getContext())
                                    .load(profileImageUrl)
                                    .placeholder(R.drawable.baseline_person_pin_24) // Placeholder image
                                    .into(profileImageView);
                        }

                        @Override
                        public void onCancelled(@NonNull DatabaseError databaseError) {
                        }
                    });
        }
    }
}
