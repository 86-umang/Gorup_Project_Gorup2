package com.example.developerhub;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;

import com.bumptech.glide.Glide;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.Map;

public class AccountFragment extends Fragment {

    private TextView userDetailsTextView;
    private ImageView profileImageView;
    private Button signoutButton;
    private FirebaseAuth mAuth;
    private DatabaseReference mDatabase;

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_account, container, false);

        mAuth = FirebaseAuth.getInstance();
        mDatabase = FirebaseDatabase.getInstance().getReference();
        FirebaseUser currentUser = mAuth.getCurrentUser();

        userDetailsTextView = view.findViewById(R.id.userDetailsTextView);
        profileImageView = view.findViewById(R.id.profileImageView);
        signoutButton = view.findViewById(R.id.signout_button);

        if (currentUser != null) {
            mDatabase.child("users").child(currentUser.getUid()).addListenerForSingleValueEvent(new ValueEventListener() {
                @Override
                public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                    RegisterActivity.User user = dataSnapshot.getValue(RegisterActivity.User.class);
                    if (user != null) {
                        StringBuilder userDetails = new StringBuilder("Name: " + user.name + "\nEmail: " + user.email + "\nUsername: " + user.username + "\nAccount Type: " + user.accountType + "\n\n");
                        if ("Developer".equals(user.accountType)) {
                            fetchDeveloperDetails(currentUser.getUid(), userDetails);
                        } else if ("HiringManager".equals(user.accountType)) {
                            fetchHiringManagerDetails(currentUser.getUid(), userDetails);
                        }
                    }
                }

                @Override
                public void onCancelled(@NonNull DatabaseError databaseError) {
                    Toast.makeText(getContext(), "Failed to load user data.", Toast.LENGTH_SHORT).show();
                }
            });
        }

        signoutButton.setOnClickListener(v -> {
            mAuth.signOut();
            // Redirect to MainActivity or any other activity you consider as the landing page after sign out.
            startActivity(new Intent(getActivity(), MainActivity.class));
            getActivity().finish();
        });

        return view;
    }

    private void fetchDeveloperDetails(String userId, StringBuilder userDetails) {
        mDatabase.child("developerDetails").child(userId).addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                Map<String, Object> details = (Map<String, Object>) dataSnapshot.getValue();
                if (details != null) {
                    userDetails.append("Developer Details:\n");
                    details.forEach((key, value) -> {
                        if (!"technologies".equals(key)) { // Skip the technologies map here
                            userDetails.append(key).append(": ").append(value).append("\n");
                        }
                    });
                    // Now handle the technologies separately
                    if (details.containsKey("technologies")) {
                        Map<String, Boolean> technologies = (Map<String, Boolean>) details.get("technologies");
                        userDetails.append("Technologies: ");
                        technologies.forEach((tech, hasSkill) -> {
                            if (Boolean.TRUE.equals(hasSkill)) {
                                userDetails.append(tech).append(", ");
                            }
                        });
                        // Remove the trailing comma and space if not empty
                        if (!technologies.isEmpty()) {
                            userDetails.setLength(userDetails.length() - 2); // Trim trailing comma and space
                        }
                        userDetails.append("\n");
                    }
                    if(details.containsKey("profileImageUrl")) {
                        Glide.with(AccountFragment.this).load(details.get("profileImageUrl").toString()).into(profileImageView);
                    }
                }
                userDetailsTextView.setText(userDetails.toString());
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
                Toast.makeText(getContext(), "Failed to load developer data.", Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void fetchHiringManagerDetails(String userId, StringBuilder userDetails) {
        mDatabase.child("hiringManagerDetails").child(userId).addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                Map<String, Object> details = (Map<String, Object>) dataSnapshot.getValue();
                if (details != null) {
                    userDetails.append("Hiring Manager Details:\n");
                    details.forEach((key, value) -> userDetails.append(key).append(": ").append(value).append("\n"));
                    if(details.containsKey("profileImageUrl")) {
                        Glide.with(AccountFragment.this).load(details.get("profileImageUrl").toString()).into(profileImageView);
                    }
                }
                userDetailsTextView.setText(userDetails.toString());
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
                Toast.makeText(getContext(), "Failed to load hiring manager data.", Toast.LENGTH_SHORT).show();
            }
        });
    }
}
