package com.example.developerhub;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.provider.MediaStore;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;

import java.util.HashMap;
import java.util.Map;

public class DeveloperEditProfileActivity  extends AppCompatActivity {

    private EditText firstNameEditText, lastNameEditText, companyNameEditText, experienceEditText, educationEditText, graduationYearEditText, trainingEditText, mobileNumberEditText;
    private Button updateButton;
    private ImageView profileImageView;
    private CheckBox javaCheckBox, kotlinCheckBox, androidCheckBox, iosCheckBox, swiftCheckBox, flutterCheckBox, reactNativeCheckBox, pythonCheckBox, djangoCheckBox, flaskCheckBox, phpCheckBox, laravelCheckBox, javascriptCheckBox, reactjsCheckBox, nodejsCheckBox, angularCheckBox;
    private Uri imageUri;
    private FirebaseAuth mAuth;
    private DatabaseReference mDatabase;
    private StorageReference mStorageRef;
    private FirebaseUser currentUser;
    LinearLayout layoutDevF;


    private ActivityResultLauncher<Intent> imagePickerActivityResultLauncher = registerForActivityResult(
            new ActivityResultContracts.StartActivityForResult(),
            result -> {
                if (result.getResultCode() == RESULT_OK && result.getData() != null) {
                    imageUri = result.getData().getData();
                    profileImageView.setImageURI(imageUri);
                }
            });

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_developer_edit_profile);

        mAuth = FirebaseAuth.getInstance();
        mDatabase = FirebaseDatabase.getInstance().getReference();
        mStorageRef = FirebaseStorage.getInstance().getReference();
        layoutDevF=findViewById(R.id.editLayoutDevF);
        firstNameEditText = findViewById(R.id.edit_fname);
        lastNameEditText = findViewById(R.id.edit_lname);
        companyNameEditText = findViewById(R.id.edit_comp_name);
        experienceEditText = findViewById(R.id.edit_experience);
        educationEditText = findViewById(R.id.edit_education);
        graduationYearEditText = findViewById(R.id.edit_graduation_year);
        trainingEditText = findViewById(R.id.edit_training);
        mobileNumberEditText = findViewById(R.id.edit_mobile);
        profileImageView = findViewById(R.id.edit_profile_image);
        currentUser = FirebaseAuth.getInstance().getCurrentUser();
        // Initialize CheckBoxes
        initCheckBoxes();

        updateButton = findViewById(R.id.btn_update);
        updateButton.setOnClickListener(v -> submitDeveloperForm());
        profileImageView.setOnClickListener(v -> pickImage());
    }

    private void initCheckBoxes() {
        javaCheckBox = findViewById(R.id.edit_java);
        kotlinCheckBox = findViewById(R.id.edit_kotlin);
        androidCheckBox = findViewById(R.id.edit_android);
        iosCheckBox = findViewById(R.id.edit_ios);
        swiftCheckBox = findViewById(R.id.edit_swift);
        flutterCheckBox = findViewById(R.id.edit_flutter);
        reactNativeCheckBox = findViewById(R.id.edit_react_native);
        pythonCheckBox = findViewById(R.id.edit_python);
        djangoCheckBox = findViewById(R.id.edit_django);
        flaskCheckBox = findViewById(R.id.edit_flask);
        phpCheckBox = findViewById(R.id.edit_php);
        laravelCheckBox = findViewById(R.id.edit_laravel);
        javascriptCheckBox = findViewById(R.id.edit_javascript);
        reactjsCheckBox = findViewById(R.id.edit_reactjs);
        nodejsCheckBox = findViewById(R.id.edit_nodejs);
        angularCheckBox = findViewById(R.id.edit_angular);
    }

    private void pickImage() {
        Intent intent = new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
        intent.setType("image/*");
        imagePickerActivityResultLauncher.launch(intent);
    }

    private void submitDeveloperForm() {
        String firstName = firstNameEditText.getText().toString().trim();
        String lastName = lastNameEditText.getText().toString().trim();
        String companyName = companyNameEditText.getText().toString().trim();
        String experience = experienceEditText.getText().toString().trim();
        String education = educationEditText.getText().toString().trim();
        String graduationYear = graduationYearEditText.getText().toString().trim();
        String training = trainingEditText.getText().toString().trim();
        String mobileNumber = mobileNumberEditText.getText().toString().trim();

        // Build a map of developer details
        Map<String, Object> developerDetails = new HashMap<>();
        developerDetails.put("firstName", firstName);
        developerDetails.put("lastName", lastName);
        developerDetails.put("companyName", companyName);
        developerDetails.put("experience", experience);
        developerDetails.put("education", education);
        developerDetails.put("graduationYear", graduationYear);
        developerDetails.put("training", training);
        developerDetails.put("mobileNumber", mobileNumber);
        // Add technology skills
        addTechnologySkillsToMap(developerDetails);

        if (!firstName.isEmpty() && !lastName.isEmpty() && imageUri != null) {
            uploadImageToFirebase();
        } else {
            UtilitySnack.showErrorSnackbar(this,layoutDevF,"Please fill in all required fields and select an image.");

        }
    }

    private void uploadImageToFirebase() {
        String firstName = firstNameEditText.getText().toString().trim();
        String lastName = lastNameEditText.getText().toString().trim();
        String companyName = companyNameEditText.getText().toString().trim();
        String experience = experienceEditText.getText().toString().trim();
        String education = educationEditText.getText().toString().trim();
        String graduationYear = graduationYearEditText.getText().toString().trim();
        String training = trainingEditText.getText().toString().trim();
        String mobileNumber = mobileNumberEditText.getText().toString().trim();

        StorageReference fileRef = mStorageRef.child("profileImages/" + mAuth.getCurrentUser().getUid() + ".jpg");
        fileRef.putFile(imageUri).addOnSuccessListener(new OnSuccessListener<UploadTask.TaskSnapshot>() {
            @Override
            public void onSuccess(UploadTask.TaskSnapshot taskSnapshot) {
                fileRef.getDownloadUrl().addOnSuccessListener(new OnSuccessListener<Uri>() {
                    @Override
                    public void onSuccess(Uri uri) {
                        Map<String, Object> developerDetails = new HashMap<>();
                        developerDetails.put("firstName", firstName);
                        developerDetails.put("lastName", lastName);
                        developerDetails.put("companyName", companyName);
                        developerDetails.put("experience", experience);
                        developerDetails.put("education", education);
                        developerDetails.put("graduationYear", graduationYear);
                        developerDetails.put("training", training);
                        developerDetails.put("mobileNumber", mobileNumber);
                        addTechnologySkillsToMap(developerDetails);
                        developerDetails.put("profileImageUrl", uri.toString()); // Save image URL

                        mDatabase.child("developerDetails").child(mAuth.getCurrentUser().getUid()).setValue(developerDetails)
                                .addOnCompleteListener(task -> {
                                    if (task.isSuccessful()) {
                                        UtilitySnack.showErrorSnackbar(DeveloperEditProfileActivity.this,layoutDevF,"Details saved successfully");

                                        new Handler().postDelayed(new Runnable() {
                                            @Override
                                            public void run() {
                                                // Start HomeActivity after a delay
                                                Intent intent = new Intent(getApplicationContext(), BottomNavigationActivity.class);
                                                startActivity(intent);
                                                finish();
                                            }
                                        }, 2000);
                                    } else {
                                        UtilitySnack.showErrorSnackbar(DeveloperEditProfileActivity.this,layoutDevF,"Failed to save developer details.");

                                    }
                                });
                    }
                });
            }
        }).addOnFailureListener(new OnFailureListener() {
            @Override
            public void onFailure(@NonNull Exception e) {
                UtilitySnack.showErrorSnackbar(DeveloperEditProfileActivity.this,layoutDevF,e.getMessage());

            }
        });
    }

    private void addTechnologySkillsToMap(Map<String, Object> developerDetails) {
        Map<String, Boolean> technologies = new HashMap<>();
        technologies.put("Java", javaCheckBox.isChecked());
        technologies.put("Kotlin", kotlinCheckBox.isChecked());
        technologies.put("Android", androidCheckBox.isChecked());
        technologies.put("iOS", iosCheckBox.isChecked());
        technologies.put("Swift", swiftCheckBox.isChecked());
        technologies.put("Flutter", flutterCheckBox.isChecked());
        technologies.put("React Native", reactNativeCheckBox.isChecked());
        technologies.put("Python", pythonCheckBox.isChecked());
        technologies.put("Django", djangoCheckBox.isChecked());
        technologies.put("Flask", flaskCheckBox.isChecked());
        technologies.put("PHP", phpCheckBox.isChecked());
        technologies.put("Laravel", laravelCheckBox.isChecked());
        technologies.put("JavaScript", javascriptCheckBox.isChecked());
        technologies.put("ReactJS", reactjsCheckBox.isChecked());
        technologies.put("NodeJS", nodejsCheckBox.isChecked());
        technologies.put("Angular", angularCheckBox.isChecked());

        // Now, filter this map to include only those entries where the value is true
        Map<String, Boolean> filteredTechnologies = new HashMap<>();
        for (Map.Entry<String, Boolean> entry : technologies.entrySet()) {
            if (entry.getValue()) {
                filteredTechnologies.put(entry.getKey(), true);
            }
        }

        // Add the filtered technologies map to the developerDetails map under a single key
        developerDetails.put("technologies", filteredTechnologies);
    }
}
