package com.example.developerhub;

import android.os.Bundle;
import android.view.MenuItem;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.android.material.navigation.NavigationBarView;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class BottomNavigationActivity extends AppCompatActivity {
    BottomNavigationView bottomNavigationView;

    private FirebaseAuth mAuth;
    private DatabaseReference mDatabase;
    private String userType = ""; // Variable to store user type

    MessageFragment messageFragment = new MessageFragment();
    SearchFragment searchFragment = new SearchFragment();
    // Note: AccountFragment is no longer needed here if we're using developer and hiring manager fragments for account info
    DeveloperFragment developerFragment = new DeveloperFragment();
    HiringManagerFragment hiringManagerFragment = new HiringManagerFragment();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_bottom_navigation);
        bottomNavigationView = findViewById(R.id.bottom_navigation);

        mAuth = FirebaseAuth.getInstance();
        mDatabase = FirebaseDatabase.getInstance().getReference();
        FirebaseUser currentUser = mAuth.getCurrentUser();

        if (currentUser != null) {
            mDatabase.child("users").child(currentUser.getUid()).addListenerForSingleValueEvent(new ValueEventListener() {
                @Override
                public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                    userType = dataSnapshot.child("accountType").getValue(String.class);
                    if ("Developer".equals(userType)) {
                        getSupportFragmentManager().beginTransaction().replace(R.id.container, developerFragment).commit();
                    } else if ("HiringManager".equals(userType)) {
                        getSupportFragmentManager().beginTransaction().replace(R.id.container, hiringManagerFragment).commit();
                    } else {
                        getSupportFragmentManager().beginTransaction().replace(R.id.container, messageFragment).commit();
                    }
                }

                @Override
                public void onCancelled(@NonNull DatabaseError databaseError) {
                    Toast.makeText(BottomNavigationActivity.this, "Failed to load user data.", Toast.LENGTH_SHORT).show();
                }
            });
        } else {
            getSupportFragmentManager().beginTransaction().replace(R.id.container, messageFragment).commit();
        }

        bottomNavigationView.setOnItemSelectedListener(new NavigationBarView.OnItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(MenuItem item) {
                int id=item.getItemId();
                if(id== R.id.message){
                    getSupportFragmentManager().beginTransaction().replace(R.id.container,messageFragment).commit();
                    return true;}
                else if (id== R.id.search){
                    getSupportFragmentManager().beginTransaction().replace(R.id.container,searchFragment).commit();
                    return true;}
                else if(id== R.id.account){
                    if ("Developer".equals(userType)) {
                        getSupportFragmentManager().beginTransaction().replace(R.id.container, developerFragment).commit();
                    } else if ("HiringManager".equals(userType)) {
                        getSupportFragmentManager().beginTransaction().replace(R.id.container, hiringManagerFragment).commit();
                    } else {
                        Toast.makeText(BottomNavigationActivity.this, "User type is undefined.", Toast.LENGTH_SHORT).show();
                    }
                    return true;
                }
                return false;
            }
        });
    }
}