package com.example.developerhub;

import java.util.Map;

public class Developer {
    private String firstName;
    private String lastName;
    private String education;
    private String graduationYear;
    private String companyName;
    private String experience;
    private String contactNo;
    private String mobileNumber;
    private Map<String, Boolean> technologies;
    private String profileImageUrl;

    // Default constructor required for calls to DataSnapshot.getValue(Developer.class)
    public Developer() {
    }

    // Constructor with parameters
    public Developer(String firstName, String lastName, String education, String graduationYear, String companyName, String experience, String contactNo, String mobileNumber, String profileImageUrl,Map<String, Boolean> technologies) {
        this.firstName = firstName;
        this.lastName = lastName;
        this.education = education;
        this.graduationYear = graduationYear;
        this.companyName = companyName;
        this.experience = experience;
        this.contactNo = contactNo;
        this.mobileNumber = mobileNumber;
        this.profileImageUrl = profileImageUrl;
        this.technologies = technologies;
    }

    // Getters
    public String getFirstName() {
        return firstName;
    }

    public String getLastName() {
        return lastName;
    }

    // Method to get the full name by combining first name and last name
    public String getFullName() {
        return firstName + " " + lastName;
    }

    public String getEducation() {
        return education;
    }

    public String getGraduationYear() {
        return graduationYear;
    }

    public String getCompanyName() {
        return companyName;
    }

    public String getExperience() {
        return experience;
    }

    public String getContactNo() {
        return contactNo;
    }

    public String getMobileNumber() { return mobileNumber; }

    public String getProfileImageUrl() {
        return profileImageUrl;
    }

    public Map<String, Boolean> getTechnologies() {
        return technologies;
    }

    public void setTechnologies(Map<String, Boolean> technologies) {
        this.technologies = technologies;
    }

    // Setters
    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public void setEducation(String education) {
        this.education = education;
    }

    public void setGraduationYear(String graduationYear) {
        this.graduationYear = graduationYear;
    }

    public void setCompanyName(String companyName) {
        this.companyName = companyName;
    }

    public void setExperience(String experience) {
        this.experience = experience;
    }

    public void setContactNo(String contactNo) {
        this.contactNo = contactNo;
    }
    public void setMobileNumber(String mobileNumber) {
        this.mobileNumber = mobileNumber;
    }

    public void setProfileImageUrl(String profileImageUrl) {
        this.profileImageUrl = profileImageUrl;
    }

    public String getTechnologyKeys() {
        if (technologies != null) {
            return String.join(", ", technologies.keySet());
        }
        return "";
    }
}
