package com.example.developerhub;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;

import com.bumptech.glide.Glide;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class DeveloperFragment extends Fragment {
    private ImageView profileImageView;
    private TextView nameTextView, educationTextView, graduationYearTextView, companyNameTextView, experienceTextView, firstNameTextView, lastNameTextView, technologyTextView, mobileNumberTextView;

    private Button editProfile, signout;

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.developer_profile_activity, container, false);

        // Initialize views
        profileImageView = view.findViewById(R.id.profileImg);
        nameTextView = view.findViewById(R.id.titleName);
        educationTextView = view.findViewById(R.id.educationName);
        graduationYearTextView = view.findViewById(R.id.graduationYear);
        companyNameTextView = view.findViewById(R.id.companyName);
        experienceTextView = view.findViewById(R.id.experienceYears);
        firstNameTextView = view.findViewById(R.id.firstName);
        lastNameTextView = view.findViewById(R.id.lastName);
        technologyTextView = view.findViewById(R.id.technology);
        mobileNumberTextView = view.findViewById(R.id.mobileNumber);
        editProfile = view.findViewById(R.id.editButton);
        signout = view.findViewById(R.id.signoutButton);

        fetchLoggedInUserInfo();

        editProfile.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getActivity(), DeveloperEditProfileActivity.class);
                startActivity(intent);
            }
        });

        signout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                signOutUser();
            }
        });

        return view;
    }

    private void signOutUser() {
        FirebaseAuth.getInstance().signOut();
        Intent intent = new Intent(getActivity(), MainActivity.class);
        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK); // Clear the back stack
        startActivity(intent);
    }

    private void fetchLoggedInUserInfo() {
        FirebaseUser currentUser = FirebaseAuth.getInstance().getCurrentUser();
        if (currentUser != null) {
            FirebaseDatabase.getInstance().getReference().child("developerDetails").child(currentUser.getUid())
                    .addListenerForSingleValueEvent(new ValueEventListener() {
                        @Override
                        public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                            String firstName = dataSnapshot.child("firstName").getValue(String.class);
                            String lastName = dataSnapshot.child("lastName").getValue(String.class);
                            String fullName = firstName + " " + lastName;
                            String education = dataSnapshot.child("education").getValue(String.class);
                            String graduationYear = dataSnapshot.child("graduationYear").getValue(String.class);
                            String companyName = dataSnapshot.child("companyName").getValue(String.class);
                            String experience = dataSnapshot.child("experience").getValue(String.class);
                            String mobileNumber = dataSnapshot.child("mobileNumber").getValue(String.class);
                            String profileImageUrl = dataSnapshot.child("profileImageUrl").getValue(String.class);
                            StringBuilder technologies = new StringBuilder();
                            for (DataSnapshot techSnapshot : dataSnapshot.child("technologies").getChildren()) {
                                if (techSnapshot.getValue(Boolean.class)) {
                                    if (technologies.length() > 0) technologies.append(", ");
                                    technologies.append(techSnapshot.getKey());
                                }
                            }

                            // Update UI
                            nameTextView.setText(fullName);
                            educationTextView.setText(education);
                            graduationYearTextView.setText(graduationYear);
                            companyNameTextView.setText(companyName);
                            experienceTextView.setText(experience + " years");
                            firstNameTextView.setText(firstName);
                            lastNameTextView.setText(lastName);
                            mobileNumberTextView.setText(mobileNumber);
                            technologyTextView.setText(technologies.toString());

                            Glide.with(getContext())
                                    .load(profileImageUrl)
                                    .placeholder(R.drawable.baseline_person_pin_24)
                                    .into(profileImageView);

                        }

                        @Override
                        public void onCancelled(@NonNull DatabaseError databaseError) {
                        }
                    });
        }
    }
}